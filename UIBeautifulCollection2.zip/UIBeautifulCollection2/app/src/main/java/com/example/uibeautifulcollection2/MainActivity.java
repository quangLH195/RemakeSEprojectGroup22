package com.example.uibeautifulcollection2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView mToggleTextView;
    private EditText edtPass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mToggleTextView = (TextView)findViewById(R.id.tv_btn_show);
        edtPass = (EditText)findViewById(R.id.edt_pass);
        mToggleTextView.setVisibility(View.GONE);
        edtPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        edtPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(edtPass.getText().length()>0){
                    mToggleTextView.setVisibility(View.VISIBLE);
                }
                else
                    mToggleTextView.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        mToggleTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mToggleTextView.getText()=="SHOW"){
                    mToggleTextView.setText("HIDE");
                    edtPass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    edtPass.setSelection(edtPass.length());
                }
                else {
                    mToggleTextView.setText("SHOW");
                    edtPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    edtPass.setSelection(edtPass.length());
                }
            }
        });
    }
}
